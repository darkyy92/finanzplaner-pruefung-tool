// Browser-compatible version of calculations.js

// Define in global namespace instead of using exports
window.FinanzplanerModules.calculations = (function() {
  // Globale Variablen für die 13. AHV-Rente
  let include13thAHVRente = true; // Standardmäßig eingeschaltet
  
  // Aktuelle Werte für 2025
  const VALUES_2025 = {
    // AHV-Werte
    ahvMinimumRente: 1260, // CHF pro Monat
    ahvMaximumRente: 2520, // CHF pro Monat
    ahvEhepaarMaximum: 3780, // CHF pro Monat (150% der Maximalrente)
    
    // BVG-Werte
    bvgMindestzinssatz: 0.0125, // 1.25%
    bvgUmwandlungssatz: 0.068, // 6.8% für obligatorischen Teil
    bvgKoordinationsabzug: 26460, // CHF
    bvgEintrittsschwelle: 22680, // CHF
    bvgVersicherterLohnMax: 90720, // CHF
    
    // Säule 3a
    saeule3aMaxEinzahlungMitPK: 7258, // CHF für Personen mit Pensionskasse
    saeule3aMaxEinzahlungOhnePK: 36288, // CHF für Personen ohne Pensionskasse
    
    // Steuerwerte Kanton Bern
    steuerBernGrenzsteuersatzMax: 0.4142, // 41.42% maximaler Grenzsteuersatz
    
    // Hypothekarzinsen
    hypothekarZinsKalkulatorisch: 0.05, // 5% für Tragbarkeitsberechnung
    
    // Inflationsrate
    inflation: 0.01, // 1% p.a.
  };
  
  // Funktion zum Umschalten der 13. AHV-Rente
  function toggle13thAHVRente(include) {
    include13thAHVRente = include;
    if (typeof recalculateAll === 'function') {
      recalculateAll();
    } else {
      console.log('13. AHV-Rente umgeschaltet, aber recalculateAll ist nicht definiert');
    }
  }
  
  // AHV-Rentenberechnung
  function calculateAHVRente(averageIncome, contributionYears, isMarried = false, spouseAverageIncome = 0, spouseContributionYears = 0) {
    // Vereinfachte Berechnung basierend auf durchschnittlichem Einkommen und Beitragsjahren
    let rente = 0;
    
    // Vollständige Beitragsdauer (44 Jahre)
    const fullContributionYears = 44;
    
    // Rentenformel vereinfacht
    if (averageIncome <= 14700) {
      // Minimale Rente bei niedrigem Einkommen
      rente = VALUES_2025.ahvMinimumRente * (contributionYears / fullContributionYears);
    } else if (averageIncome >= 88200) {
      // Maximale Rente bei hohem Einkommen
      rente = VALUES_2025.ahvMaximumRente * (contributionYears / fullContributionYears);
    } else {
      // Lineare Interpolation für Einkommen zwischen Min und Max
      const renteFaktor = (averageIncome - 14700) / (88200 - 14700);
      const volleRente = VALUES_2025.ahvMinimumRente + renteFaktor * (VALUES_2025.ahvMaximumRente - VALUES_2025.ahvMinimumRente);
      rente = volleRente * (contributionYears / fullContributionYears);
    }
    
    // Monatliche Rente
    let monthlyRente = rente;
    
    // Für Ehepaare: Plafonierung auf 150% der Maximalrente
    if (isMarried) {
      // Berechnung der Rente des Ehepartners
      let spouseRente = 0;
      
      if (spouseAverageIncome <= 14700) {
        spouseRente = VALUES_2025.ahvMinimumRente * (spouseContributionYears / fullContributionYears);
      } else if (spouseAverageIncome >= 88200) {
        spouseRente = VALUES_2025.ahvMaximumRente * (spouseContributionYears / fullContributionYears);
      } else {
        const spouseRenteFaktor = (spouseAverageIncome - 14700) / (88200 - 14700);
        const spouseVolleRente = VALUES_2025.ahvMinimumRente + spouseRenteFaktor * (VALUES_2025.ahvMaximumRente - VALUES_2025.ahvMinimumRente);
        spouseRente = spouseVolleRente * (spouseContributionYears / fullContributionYears);
      }
      
      // Gemeinsame Rente mit Plafonierung
      const combinedRente = rente + spouseRente;
      if (combinedRente > VALUES_2025.ahvEhepaarMaximum) {
        // Plafonierung auf 150% der Maximalrente
        const reductionFactor = VALUES_2025.ahvEhepaarMaximum / combinedRente;
        monthlyRente = rente * reductionFactor;
      }
    }
    
    // Jährliche Rente (12 Monate)
    let yearlyRente = monthlyRente * 12;
    
    // 13. AHV-Rente hinzufügen, wenn aktiviert
    if (include13thAHVRente) {
      yearlyRente += monthlyRente; // 13. Rente = 1 zusätzliche Monatsrente
    }
    
    return {
      monthlyRente: monthlyRente,
      yearlyRente: yearlyRente,
      with13thRente: include13thAHVRente
    };
  }
  
  // AHV-Rente mit expliziter 13. AHV-Rente
  function calculateAHVRenteWith13th(averageIncome, contributionYears, isMarried = false, spouseAverageIncome = 0, spouseContributionYears = 0) {
    // Berechne die normale AHV-Rente (12 Monate)
    const baseRente = calculateAHVRente(averageIncome, contributionYears, isMarried, spouseAverageIncome, spouseContributionYears);
    
    // 13. Rente ist gleich der monatlichen Rente
    const thirteenthRente = baseRente.monthlyRente;
    
    // Jährliche Rente mit 13. Rente
    const yearlyRenteWith13th = baseRente.monthlyRente * 13;
    
    return {
      monthlyRente: baseRente.monthlyRente,
      thirteenthRente: thirteenthRente,
      yearlyRenteWith13th: yearlyRenteWith13th
    };
  }
  
  // Expose the public functions and values
  return {
    VALUES_2025: VALUES_2025,
    toggle13thAHVRente: toggle13thAHVRente,
    calculateAHVRente: calculateAHVRente,
    calculateAHVRenteWith13th: calculateAHVRenteWith13th,
    // Add other calculation functions here
  };
})();