# Maßnahmenplan

## Zeitlich geordnete Maßnahmen

### Sofort umzusetzende Maßnahmen (innerhalb von 1 Monat)

#### Vorsorge
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

2. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Steuern
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

2. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Anlagen
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

2. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Immobilien
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Nachlass
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

### Kurzfristige Maßnahmen (1-6 Monate)

#### Vorsorge
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

2. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Steuern
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Anlagen
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Immobilien
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Nachlass
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

### Mittelfristige Maßnahmen (6-24 Monate)

#### Vorsorge
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Steuern
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Anlagen
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Immobilien
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Nachlass
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

### Langfristige Maßnahmen (> 24 Monate)

#### Vorsorge
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Steuern
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Anlagen
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Immobilien
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

#### Nachlass
1. □ _________________
   * Priorität: □ hoch □ mittel □ niedrig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________
   * Notizen: _________________

## Prioritäten

### Höchste Priorität
1. □ _________________
   * Bereich: □ Vorsorge □ Steuern □ Anlagen □ Immobilien □ Nachlass
   * Zeitrahmen: □ sofort □ kurzfristig □ mittelfristig □ langfristig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________

2. □ _________________
   * Bereich: □ Vorsorge □ Steuern □ Anlagen □ Immobilien □ Nachlass
   * Zeitrahmen: □ sofort □ kurzfristig □ mittelfristig □ langfristig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________

3. □ _________________
   * Bereich: □ Vorsorge □ Steuern □ Anlagen □ Immobilien □ Nachlass
   * Zeitrahmen: □ sofort □ kurzfristig □ mittelfristig □ langfristig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________

### Mittlere Priorität
1. □ _________________
   * Bereich: □ Vorsorge □ Steuern □ Anlagen □ Immobilien □ Nachlass
   * Zeitrahmen: □ sofort □ kurzfristig □ mittelfristig □ langfristig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________

2. □ _________________
   * Bereich: □ Vorsorge □ Steuern □ Anlagen □ Immobilien □ Nachlass
   * Zeitrahmen: □ sofort □ kurzfristig □ mittelfristig □ langfristig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________

### Niedrigere Priorität
1. □ _________________
   * Bereich: □ Vorsorge □ Steuern □ Anlagen □ Immobilien □ Nachlass
   * Zeitrahmen: □ sofort □ kurzfristig □ mittelfristig □ langfristig
   * Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
   * Erwarteter Nutzen: _________________

## Meilensteine

### Meilenstein 1
* Beschreibung: _________________
* Zieldatum: _________________
* Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
* Status: □ offen □ in Bearbeitung □ abgeschlossen

### Meilenstein 2
* Beschreibung: _________________
* Zieldatum: _________________
* Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
* Status: □ offen □ in Bearbeitung □ abgeschlossen

### Meilenstein 3
* Beschreibung: _________________
* Zieldatum: _________________
* Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater
* Status: □ offen □ in Bearbeitung □ abgeschlossen

## Überwachung und Anpassung

### Regelmäßige Überprüfung
* Häufigkeit: □ vierteljährlich □ halbjährlich □ jährlich
* Nächster Termin: _________________
* Verantwortlich: □ Kunde/Kundin 1 □ Kunde/Kundin 2 □ Beide □ Berater

### Anpassungskriterien
* Änderungen in der persönlichen Situation: _________________
* Änderungen in der finanziellen Situation: _________________
* Änderungen im rechtlichen/steuerlichen Umfeld: _________________
* Andere Kriterien: _________________
